#!/system/bin/sh
# This binary has been succesfully replaced. This script will hang forever so it is not launched again.
while :; do sleep 2073600; done
