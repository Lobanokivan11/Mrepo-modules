# Luz Nocturna Modded

---
## Vista rápida
- Modifica los valores mínimos del modo Luz Nocturna para permitir bajar la tonalidad cálida excesiva

## Compatibilidad
- Android 10-12.1 (Puede ser compatible con versiones inferiores de Android o con Android 13, pero no ha sido probado).
- Sólo ha sido probado en ROMs estilo AOSP. No funcionará en capas gráficas tales como Miui y otras similares.

---

*ENGLISH VERSION*

---

# Modded Night Light

---
## Quick View
- Modifies the minimum values of the Night Light mode to allow for lowering the excessive warm hue.

## Compatibility
- Android 10-12.1 (May be compatible with lower versions of Android or Android 13, but has not been tested).
- Has only been tested on AOSP style ROMs. It will not work on graphical overlays such as Miui and the like.
